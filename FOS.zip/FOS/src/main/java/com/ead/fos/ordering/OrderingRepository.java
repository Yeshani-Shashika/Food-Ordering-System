package com.ead.fos.ordering;

import org.springframework.data.jpa.repository.JpaRepository;

public interface OrderingRepository extends JpaRepository<Ordering, Integer>{
}
