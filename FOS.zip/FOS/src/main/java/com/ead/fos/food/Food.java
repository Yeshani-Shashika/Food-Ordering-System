package com.ead.fos.food;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.ead.fos.ordering.Ordering;

@Entity
public class Food {
    @GeneratedValue(strategy = GenerationType.IDENTITY) @Id private int id;
    @Column(unique = true, nullable = false) private String foodName;
    @Column(nullable = false) private double foodPrice;
    @ManyToMany(mappedBy = "orderFoodItems")
	@JsonIgnore
	private List<Ordering> ordersIncludedIn;

    public Food() {
    }
    
    public Food(int id, String foodName, double foodPrice, List<Ordering> ordersIncludedIn) {
        this.id = id;
        this.foodName = foodName;
        this.foodPrice = foodPrice;
        this.ordersIncludedIn = ordersIncludedIn;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFoodName() {
        return foodName;
    }

    public void setFoodName(String foodName) {
        this.foodName = foodName;
    }

    public double getFoodPrice() {
        return foodPrice;
    }

    public void setFoodPrice(double foodPrice) {
        this.foodPrice = foodPrice;
    }

    public List<Ordering> getOrdersIncludedIn() {
        return ordersIncludedIn;
    }

    public void setOrdersIncludedIn(List<Ordering> ordersIncludedIn) {
        this.ordersIncludedIn = ordersIncludedIn;
    }
}
