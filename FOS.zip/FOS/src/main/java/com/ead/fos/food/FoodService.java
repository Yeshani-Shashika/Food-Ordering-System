package com.ead.fos.food;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class FoodService {
    
    @Autowired
    private FoodRepository foodRepository;
    
    public List<Food> getAllFoodItems() throws Exception{
        return this.foodRepository.findAll();
    }

    public Food getFoodItemById(int id) throws Exception{
        Optional<Food> result = this.foodRepository.findById(id);
        if(result.isPresent()) return result.get();
        else throw new Exception("Food not found");
    }

    public Food addFoodItem(Food foodResource) throws Exception{
        if(this.foodRepository.findByFoodName(foodResource.getFoodName()).isEmpty()){

            Food newFoodItem = new Food();
    
            newFoodItem.setFoodName(foodResource.getFoodName());
            newFoodItem.setFoodPrice(foodResource.getFoodPrice());
    
            Food addedFood = this.foodRepository.save(newFoodItem);

            return addedFood;
        }
        else{
            throw new Exception("Food Name already exists");
        }
    }

    public Food updateFoodItem(int id, Food foodResource) throws Exception{
        Optional<Food> result = this.foodRepository.findById(id);
        if(result.isPresent()){
            Food newFood = result.get();

            if(newFood.getFoodName().equals(foodResource.getFoodName()) || this.foodRepository.findByFoodName(foodResource.getFoodName()).isEmpty()){
                newFood.setFoodName(foodResource.getFoodName());
                newFood.setFoodPrice(foodResource.getFoodPrice());
    
                this.foodRepository.save(newFood);
                return newFood;
            }
            else{
                throw new Exception("Food Name already exists");
            }
        }
        else{
            throw new Exception("Food not found");
        }
    }

    public Food removeFoodItem(int id) throws Exception{
        Optional<Food> result = this.foodRepository.findById(id);
        if(result.isPresent()){
            this.foodRepository.delete(result.get());
            return result.get();
        }
        else throw new Exception("Food not found");
    }

}
