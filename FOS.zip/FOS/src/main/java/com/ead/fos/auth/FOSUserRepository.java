package com.ead.fos.auth;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

public interface FOSUserRepository extends JpaRepository<FOSUser, Integer> {
    Optional<FOSUser> findByUserName(String userName);  
}
