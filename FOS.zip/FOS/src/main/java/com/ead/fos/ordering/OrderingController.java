package com.ead.fos.ordering;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class OrderingController {
    
    @Autowired
    OrderingService orderingService;

    @ExceptionHandler({ Exception.class })
    public ResponseEntity handleException(Exception ex) {
        return ResponseEntity.status(HttpStatus.CONFLICT).body(ex.getMessage());
    }

    
    @RequestMapping("/order")
    public List<Ordering> getAllOrderings() throws Exception{
        return this.orderingService.getAllOrderings();
    }

    @RequestMapping("/order/{id}")
    public Ordering getfoodOrderingById(@PathVariable int id) throws Exception{
        return this.orderingService.getOrderingByid(id);
    }

    @RequestMapping(method = RequestMethod.POST, value = "/order/add")
    public Ordering addOrdering(@RequestBody Ordering orderingResource) throws Exception{
        return this.orderingService.addOrdering(orderingResource);
    }

    @RequestMapping(method = RequestMethod.DELETE, value = "/order/{id}/remove")
    public Ordering removeOrdering(@PathVariable int id) throws Exception{
        return this.orderingService.removeOrdering(id);
    }

    @RequestMapping(method = RequestMethod.PUT, value = "/order/{id}/update")
    public Ordering updateMenu(@PathVariable int id, @RequestBody Ordering orderingResource) throws Exception{
        return this.orderingService.updateOrdering(id, orderingResource);
    }
}