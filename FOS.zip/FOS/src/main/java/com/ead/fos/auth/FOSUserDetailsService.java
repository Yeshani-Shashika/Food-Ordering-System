package com.ead.fos.auth;

import java.util.Optional;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
public class FOSUserDetailsService implements UserDetailsService {

    @Autowired
    FOSUserRepository userRepository;

    @Value("${db.security.admin}")
    private String admin;

    @Value("${db.security.password}")
    private String password;

    @PostConstruct
    public void initializeAdmin() {
        this.userRepository.save(new FOSUser(1, admin, password, true, "ROLE_ADMIN"));
    }

    @Override
    public UserDetails loadUserByUsername(String userName) throws UsernameNotFoundException {
        Optional<FOSUser> user = userRepository.findByUserName(userName);
        user.orElseThrow(() -> new UsernameNotFoundException("User not found"));
        return user.map(FOSUserDetails::new).get();
    }
    
}
