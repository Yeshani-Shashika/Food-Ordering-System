package com.ead.fos.ordering;

import java.util.List;
import java.util.Optional;

import com.ead.fos.auth.FOSUserRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class OrderingService {

    @Autowired
    private OrderingRepository orderingRepository;

    @Autowired
    FOSUserRepository userRepository;

    public Ordering getOrderingByid(int id) throws Exception{
        Optional<Ordering> result = this.orderingRepository.findById(id);
        if(result.isPresent()){
            return result.get();
        }
        else{
            throw new Exception("Order not found");
        }
    }

    public List<Ordering> getAllOrderings() throws Exception{
        return this.orderingRepository.findAll();
    }

    public Ordering addOrdering(Ordering orderingResource) throws Exception{
        Ordering newOrder = new Ordering();
        newOrder.setOrderFoodItems(orderingResource.getOrderFoodItems());

        Ordering addedOrdering = this.orderingRepository.save(newOrder);

        return addedOrdering;
    }

    public Ordering removeOrdering(int id) throws Exception{
        Optional<Ordering> result = this.orderingRepository.findById(id);
        if(result.isPresent()){
            this.orderingRepository.delete(result.get());
            return result.get();
        }
        else{
            throw new Exception("Order not found");
        }
    }

    public Ordering updateOrdering(int id, Ordering orderingResource) throws Exception{
        if(this.orderingRepository.findById(id).isPresent()){
            Ordering newOrdering = this.orderingRepository.findById(id).get();
            newOrdering.setOrderFoodItems(orderingResource.getOrderFoodItems());
            return newOrdering;
        }
        else{
            throw new Exception("Order not found");
        }
    }

}