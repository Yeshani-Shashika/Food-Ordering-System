package com.ead.fos.ordering;

import java.util.List;

import com.ead.fos.food.Food;

public class OrderingResource {
    private List<Food> orderFoodItems;

    public OrderingResource() {
    }

    public OrderingResource(List<Food> orderFoodItems) {
        this.orderFoodItems = orderFoodItems;
    }

    public List<Food> getOrderFoodItems() {
        return orderFoodItems;
    }

    public void setOrderFoodItems(List<Food> orderFoodItems) {
        this.orderFoodItems = orderFoodItems;
    }
}
