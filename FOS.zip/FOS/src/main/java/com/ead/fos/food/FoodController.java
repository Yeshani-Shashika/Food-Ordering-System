package com.ead.fos.food;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.view.RedirectView;

@Controller
@RequestMapping("/food")
public class FoodController {
    
    @Autowired
    private FoodService foodService;

    @ExceptionHandler({ Exception.class })
    public ResponseEntity handleException(Exception ex) {
        return ResponseEntity.status(HttpStatus.CONFLICT).body(ex.getMessage());
    }

    @RequestMapping()
    public String getAllFoodItems(Model model) throws Exception{
        model.addAttribute("foodItems", this.foodService.getAllFoodItems());
        return "view-food";
    }

    @RequestMapping("/{id}")
    public String getFoodItemByCode(@PathVariable int id, Model model) throws Exception{
        model.addAttribute("foodItem", this.foodService.getFoodItemById(id));
        return "view-food-item";
    }

    @RequestMapping("/add")
    public String getFoodAddView(Model model) throws Exception{
        model.addAttribute("foodItem", new Food());
        model.addAttribute("isUpdating", false);
        return "add-food-item";
    }

    @RequestMapping(method = RequestMethod.POST, value = "/add")
    public RedirectView addFoodItem(@ModelAttribute("foodItem") Food foodItem) throws Exception{
        this.foodService.addFoodItem(foodItem);
        return new RedirectView("/food");
    }

    @RequestMapping("/{id}/update")
    public String getFoodUpdateView(@PathVariable int id, Model model) throws Exception{
        model.addAttribute("foodItem", this.foodService.getFoodItemById(id));
        model.addAttribute("isUpdating", true);
        return "add-food-item";
    }

    @RequestMapping(method = RequestMethod.POST, value = "/{id}/update")
    public RedirectView updateFoodItem(@PathVariable int id, @ModelAttribute("foodItem") Food foodItem) throws Exception{
        this.foodService.updateFoodItem(id, foodItem);
        return new RedirectView("/food");
    }

    @RequestMapping(method = RequestMethod.POST, value = "/{id}/remove")
    public RedirectView removeFoodItem(@ModelAttribute("foodItem") Food foodItem) throws Exception{
        this.foodService.removeFoodItem(foodItem.getId());
        final RedirectView redirectView = new RedirectView("/food");
        return redirectView;
    }

}