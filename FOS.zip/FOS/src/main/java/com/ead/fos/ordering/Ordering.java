package com.ead.fos.ordering;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;

import com.ead.fos.food.Food;

@Entity
public class Ordering {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private int id;
    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(
        name = "ordering_food",
        joinColumns = @JoinColumn(name = "food_id"),
        inverseJoinColumns = @JoinColumn(name = "ordering_id")
    )
    private List<Food> orderFoodItems;

    public Ordering() {
    }

    public Ordering(int id, List<Food> orderFoodItems) {
        this.id = id;
        this.orderFoodItems = orderFoodItems;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public List<Food> getOrderFoodItems() {
        return orderFoodItems;
    }

    public void setOrderFoodItems(List<Food> orderFoodItems) {
        this.orderFoodItems = orderFoodItems;
    }
}
